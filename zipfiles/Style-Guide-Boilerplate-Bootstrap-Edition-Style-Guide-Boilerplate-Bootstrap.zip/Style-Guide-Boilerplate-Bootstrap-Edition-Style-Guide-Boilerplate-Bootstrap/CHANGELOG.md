1.1.0 / 2015-01-18
==================

  * Added the ability to add usage notes for elements
  * Moved code to functions.php
  * Cleaned markup for wells, buttons & advanced buttons
  * Style fixes
  

1.0.4 / 2014-11-18
==================

  * Fixed incorrect padding /nesting

1.0.3 / 2014-07-25
==================

  * Deleted unneccesary files

  
1.0.2 / 2014-04-15
==================

  * Moved Foundation to external files
  * Added dropdown headers
  * Moved docs to external files, added project_name variable
  * Fixed color & style classes
  * Style fixes

1.0.1 / 2014-03-06
==================

  * Deleted non-Bootstrap files
  * Fixed IDs and padding


1.0.0 / 2014-02-24
==================

  * Initial commit
